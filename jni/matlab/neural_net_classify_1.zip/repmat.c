/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: repmat.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 16:47:25
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "repmat.h"

/* Function Definitions */

/*
 * Arguments    : double b[496]
 * Return Type  : void
 */
void b_repmat(double b[496])
{
  int jtilecol;
  int ibtile;
  int k;
  static const double a[4] = { -0.11713315414167959, 0.30208853606930675,
    0.14093347775548681, 0.81704497053668734 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol << 2;
    for (k = 0; k < 4; k++) {
      b[ibtile + k] = a[k];
    }
  }
}

/*
 * Arguments    : double b[2604]
 * Return Type  : void
 */
void repmat(double b[2604])
{
  int jtilecol;
  int ibtile;
  static const double a[21] = { 0.97407192943631848, -0.71578413331862012,
    0.84905634360057225, 0.91882948959573207, 0.786141831398867,
    1.4039539153236873, 0.491554319376554, -1.3002280244417177,
    0.32861408257315444, -1.392247100887283, -0.34098055938862654,
    -0.26713807504059411, 0.038266091994130211, 1.1114656027389604,
    -0.97509566971688189, -1.272274475659366, 0.36560189987246738,
    -0.3442938221508659, 3.0435731883354613, 1.1176220448842547,
    -1.3629563834880789 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol * 21;
    memcpy(&b[ibtile], &a[0], 21U * sizeof(double));
  }
}

/*
 * File trailer for repmat.c
 *
 * [EOF]
 */
