/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: neural_net.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 16:47:25
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "neural_net.h"
#include "repmat.h"

/* Function Declarations */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488]);
static void mapminmax_reverse(const float y[496], float x[496]);
static void softmax_apply(float n[496], float a[496]);
static void tansig_apply(const float n[2604], float a[2604]);

/* Function Definitions */

/*
 * Arguments    : const float x[1488]
 *                const double settings_gain[12]
 *                const double settings_xoffset[12]
 *                float y[1488]
 * Return Type  : void
 */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488])
{
  int ak;
  int ck;
  float cv[12];
  int k;
  float a[1488];

  /*  ===== MODULE FUNCTIONS ======== */
  /*  Map Minimum and Maximum Input Processing Function */
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = x[ak + k] - (float)settings_xoffset[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] * (float)settings_gain[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] + -1.0F;
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }
}

/*
 * Arguments    : const float y[496]
 *                float x[496]
 * Return Type  : void
 */
static void mapminmax_reverse(const float y[496], float x[496])
{
  int ak;
  int ck;
  float cv[4];
  int k;
  float a[496];

  /*  Map Minimum and Maximum Output Reverse-Processing Function */
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = y[ak + k] - -1.0F;
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }

  memcpy(&a[0], &x[0], 496U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k] / 2.0F;
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }

  memcpy(&a[0], &x[0], 496U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k];
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }
}

/*
 * Arguments    : float n[496]
 *                float a[496]
 * Return Type  : void
 */
static void softmax_apply(float n[496], float a[496])
{
  float nmax[124];
  int ix;
  int iy;
  int i;
  int bk;
  float mtmp;
  int ak;
  boolean_T exitg1;
  float cv[4];
  int k;
  float numer[496];
  float s;
  float b_nmax;

  /*  Competitive Soft Transfer Function */
  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ix += 4;
    bk = ix - 3;
    mtmp = n[ix - 4];
    if (rtIsNaNF(n[ix - 4])) {
      ak = ix - 2;
      exitg1 = false;
      while ((!exitg1) && (ak <= ix)) {
        bk = ak;
        if (!rtIsNaNF(n[ak - 1])) {
          mtmp = n[ak - 1];
          exitg1 = true;
        } else {
          ak++;
        }
      }
    }

    if (bk < ix) {
      while (bk + 1 <= ix) {
        if (n[bk] > mtmp) {
          mtmp = n[bk];
        }

        bk++;
      }
    }

    iy++;
    nmax[iy] = mtmp;
  }

  memcpy(&a[0], &n[0], 496U * sizeof(float));
  ak = 0;
  bk = 0;
  for (ix = 0; ix < 494; ix += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k] - nmax[bk];
    }

    for (k = 0; k < 4; k++) {
      n[ix + k] = cv[k];
    }

    ak += 4;
    bk++;
  }

  for (ak = 0; ak < 496; ak++) {
    numer[ak] = (real32_T)exp(n[ak]);
  }

  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ak = ix;
    ix++;
    s = numer[ak];
    for (k = 0; k < 3; k++) {
      ix++;
      s += numer[ix - 1];
    }

    iy++;
    nmax[iy] = s;
  }

  for (i = 0; i < 124; i++) {
    b_nmax = nmax[i];
    if (nmax[i] == 0.0F) {
      b_nmax = 1.0F;
    }

    nmax[i] = b_nmax;
  }

  ak = 0;
  bk = 0;
  for (ix = 0; ix < 494; ix += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = numer[ak + k] / nmax[bk];
    }

    for (k = 0; k < 4; k++) {
      a[ix + k] = cv[k];
    }

    ak += 4;
    bk++;
  }
}

/*
 * Arguments    : const float n[2604]
 *                float a[2604]
 * Return Type  : void
 */
static void tansig_apply(const float n[2604], float a[2604])
{
  int i3;

  /*  Sigmoid Symmetric Transfer Function */
  for (i3 = 0; i3 < 2604; i3++) {
    a[i3] = 2.0F / (1.0F + (real32_T)exp(-2.0F * n[i3])) - 1.0F;
  }
}

/*
 * NEURAL_NET neural network simulation function.
 *
 *  Generated by Neural Network Toolbox function genFunction, 18-Mar-2016 16:46:06.
 *
 *  [y1] = neural_net(x1) takes these arguments:
 *    x = 12xQ matrix, input #1
 *  and returns:
 *    y = 4xQ matrix, output #1
 *  where Q is the number of samples.
 * Arguments    : const float x1[1488]
 *                float b_y1[496]
 * Return Type  : void
 */
void neural_net(const float x1[1488], float b_y1[496])
{
  float xp1[1488];
  static const double dv0[12] = { 14.217573, -44.983524, -18.36889, -4.2858396,
    -41.104713, -11.332692, -11.150261, -44.45419, -10.271046, -12.9821005,
    -33.2938, -13.485515 };

  static const double dv1[12] = { 0.0786732635247109, 0.0509866859333796,
    0.0430732106962929, 0.0561952801269528, 0.0504921223541367,
    0.0386407595057669, 0.0404083579758653, 0.0387105587214169,
    0.0430077689663939, 0.0429843487431113, 0.0453174467887638,
    0.0413112530469373 };

  double dv2[496];
  double dv3[2604];
  float fv0[2604];
  int i0;
  int i1;
  float f0;
  int i2;
  static const float fv1[252] = { -1.29160154F, 0.97170943F, -1.34147668F,
    -1.4667865F, 0.104812622F, -0.454940826F, -0.828402698F, -0.299504727F,
    -0.68665427F, 1.06418741F, 0.261708528F, -0.507770777F, -0.616451859F,
    -0.130362734F, -2.22341228F, -1.33765006F, 0.870658755F, 1.08517981F,
    -0.353117585F, 1.38025272F, -2.6615026F, 2.84724402F, -0.754548848F,
    0.239924178F, 2.22606826F, 0.305404902F, 1.7461437F, -0.516796649F,
    -0.543719351F, -0.295718193F, 0.17620638F, -1.68704569F, -0.537295282F,
    -1.11011136F, -0.10477984F, 2.37630177F, -0.804901898F, 0.258357674F,
    0.0903639719F, 0.214148447F, -0.970963836F, 2.05397558F, 1.7842778F,
    0.705605209F, 0.875764906F, 2.6882844F, -0.301980197F, 2.21748281F,
    0.65208447F, -0.873238325F, 0.39409253F, 1.87896156F, -1.00703895F,
    -1.26957548F, -0.512579858F, -0.230709389F, 1.36014974F, 0.59871F,
    -0.91336894F, -0.889439464F, -0.544226766F, -0.143183351F, 2.76337624F,
    1.23764241F, 0.385465503F, 0.200141147F, 0.641690433F, -0.150734499F,
    0.467662573F, 0.286839575F, 1.18776035F, 0.113051422F, 2.14473772F,
    -0.702009201F, -0.927664459F, -0.308037668F, -0.989026487F, -0.147229493F,
    -0.521015F, -0.461148292F, -0.167345211F, -2.21309304F, -0.737241864F,
    0.197789922F, 0.249577403F, 0.665720284F, 0.668160617F, -0.10213992F,
    0.359518766F, -0.352936566F, -0.967148602F, 0.131239802F, -0.22838524F,
    -0.360130399F, 0.777390778F, 0.576915562F, -0.149451777F, 0.941195F,
    -0.229594529F, -1.64951289F, 0.799191177F, 1.24993074F, 0.143672854F,
    0.911872506F, -1.2666136F, -1.18626142F, -0.275821179F, 0.558826387F,
    -0.611592F, -0.303211212F, -0.555122614F, 0.312820822F, -0.447086215F,
    -0.616626799F, -1.47326505F, 0.726022124F, 1.21058857F, -0.263933867F,
    0.544558585F, 0.354117602F, 1.9867655F, 0.840788F, -0.119873524F,
    2.26925707F, 0.202198058F, 1.12694752F, -0.150981173F, -1.21575129F,
    1.07106483F, 0.0974887088F, -1.28300297F, -0.0036744352F, 0.543734968F,
    -0.174958229F, -0.908006728F, -1.34752393F, -0.0444102958F, -0.46812132F,
    0.449113041F, 0.315280378F, 1.35305119F, 2.62538862F, -0.228774443F,
    0.48423627F, 1.10144198F, -0.0269875F, 2.61557984F, 0.72033608F,
    0.236166358F, 0.538161516F, 0.463754773F, 0.682261527F, -1.44273472F,
    0.311960965F, 0.980355859F, -0.23414062F, 1.31337595F, 0.509519756F,
    0.519350648F, -0.858850777F, 0.978481472F, 0.0297059789F, -1.20579386F,
    0.0532935709F, 1.28541815F, -1.83119118F, 0.200517952F, -1.57605267F,
    -0.913606703F, 0.854947269F, -0.708774507F, -0.633478165F, -0.104858853F,
    -1.17833817F, 0.313461125F, 0.335638404F, 0.257461101F, 0.629874349F,
    -0.161413759F, 0.551450372F, -0.530638099F, -0.0998981893F, -0.898508728F,
    -1.30325413F, -0.783926964F, 0.898266256F, -1.98566043F, 0.493773848F,
    -0.59334451F, 0.546609223F, -0.930386961F, 0.265870899F, 0.0288852546F,
    -1.13214433F, 0.675227165F, 0.813183904F, -0.121479951F, -0.797795475F,
    -0.582617044F, 1.23227954F, -0.340550125F, 1.04318F, -0.253486186F,
    1.28624809F, 1.6409595F, -0.643970668F, 0.603745461F, 0.319806188F,
    -0.354339242F, 2.50285339F, -0.405855626F, -0.533595264F, -0.0169218704F,
    0.916841865F, -0.0337081663F, -0.78115958F, -0.483680487F, -0.26590237F,
    -0.319922745F, 0.532462299F, 0.122781768F, 0.668566525F, -0.47046113F,
    1.16123366F, 0.20886004F, -0.405522615F, -0.0877437592F, 1.13691342F,
    -0.519986928F, 0.93929553F, -1.82261455F, 0.23854661F, -0.312292F,
    -0.757130623F, -0.790931463F, 0.657405555F, -0.518103361F, 0.549357593F,
    1.25034094F, -0.680789411F, 0.0109552564F, -0.0667258352F, 0.306996554F,
    -0.564562201F, 0.098564364F, 0.287809372F, 0.603189051F, 0.538840771F,
    -1.48569059F, 0.535443F, -0.937848747F, 0.493474F };

  float fv2[2604];
  float fv3[496];
  static const float fv4[84] = { 2.5853126F, 0.393334478F, -1.24944758F,
    -2.02192473F, 0.0368523784F, -0.519577086F, 1.56456459F, 0.227189779F,
    0.851169169F, -0.481628F, -1.22951913F, 0.688880146F, 3.67593932F,
    0.597504675F, -1.67810619F, -1.16874337F, 0.885427833F, -0.977938652F,
    0.431592F, -0.0541464612F, 0.0889355F, 2.32975864F, 0.4016307F, -2.37064815F,
    -0.0946519673F, 0.802956939F, -0.366543174F, -0.201260388F, 0.44639948F,
    -1.46007574F, 0.0597606115F, -0.474343836F, -0.300098032F, -0.58675462F,
    -0.0896078572F, -0.750592351F, 3.25907683F, -0.64254415F, -0.143312976F,
    -0.775543749F, -1.21194434F, -1.12841702F, -0.95220691F, 2.10812902F,
    0.304181457F, -0.937707603F, -0.426243722F, 1.62552166F, -1.09228361F,
    0.693830848F, 0.0652927831F, 0.538886726F, 0.655368447F, -1.35730481F,
    -0.468933284F, 1.42074132F, -1.24488354F, 2.09301519F, -1.47248697F,
    -1.60902154F, -2.61703539F, 2.10621548F, -0.120420627F, 1.58377755F,
    0.100702271F, -0.883213639F, 1.03775418F, -0.270405829F, 1.73308361F,
    -1.1834631F, -0.539358199F, 1.71630692F, -3.22065067F, 2.4473834F,
    -0.497563362F, 0.0584788062F, 1.16576231F, -1.67188752F, -1.26301193F,
    1.07578146F, -3.20933056F, 5.10585499F, 0.390671462F, 0.166767105F };

  float fv5[496];

  /*  ===== NEURAL NETWORK CONSTANTS ===== */
  /*  Input 1 */
  /*  Layer 1 */
  /*  Layer 2 */
  /*  Output 1 */
  /*  ===== SIMULATION ======== */
  /*  Dimensions */
  /*  samples */
  /*  Input 1 */
  mapminmax_apply(x1, dv1, dv0, xp1);

  /*  Layer 1 */
  /*  Layer 2 */
  b_repmat(dv2);
  repmat(dv3);
  for (i0 = 0; i0 < 21; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 12; i2++) {
        f0 += fv1[i0 + 21 * i2] * xp1[i2 + 12 * i1];
      }

      fv0[i0 + 21 * i1] = (float)dv3[i0 + 21 * i1] + f0;
    }
  }

  tansig_apply(fv0, fv2);
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 21; i2++) {
        f0 += fv4[i0 + (i2 << 2)] * fv2[i2 + 21 * i1];
      }

      fv3[i0 + (i1 << 2)] = (float)dv2[i0 + (i1 << 2)] + f0;
    }
  }

  /*  Output 1 */
  softmax_apply(fv3, fv5);
  mapminmax_reverse(fv5, b_y1);
}

/*
 * File trailer for neural_net.c
 *
 * [EOF]
 */
