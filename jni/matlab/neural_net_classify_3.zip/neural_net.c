/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: neural_net.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 17:54:44
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "neural_net.h"
#include "repmat.h"

/* Function Declarations */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488]);
static void mapminmax_reverse(const float y[372], float x[372]);
static void softmax_apply(float n[372], float a[372]);
static void tansig_apply(const float n[1240], float a[1240]);

/* Function Definitions */

/*
 * Arguments    : const float x[1488]
 *                const double settings_gain[12]
 *                const double settings_xoffset[12]
 *                float y[1488]
 * Return Type  : void
 */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488])
{
  int ak;
  int ck;
  float cv[12];
  int k;
  float a[1488];

  /*  ===== MODULE FUNCTIONS ======== */
  /*  Map Minimum and Maximum Input Processing Function */
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = x[ak + k] - (float)settings_xoffset[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] * (float)settings_gain[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] + -1.0F;
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }
}

/*
 * Arguments    : const float y[372]
 *                float x[372]
 * Return Type  : void
 */
static void mapminmax_reverse(const float y[372], float x[372])
{
  int ak;
  int ck;
  float cv[3];
  int k;
  float a[372];

  /*  Map Minimum and Maximum Output Reverse-Processing Function */
  ak = 0;
  for (ck = 0; ck < 371; ck += 3) {
    for (k = 0; k < 3; k++) {
      cv[k] = y[ak + k] - -1.0F;
    }

    for (k = 0; k < 3; k++) {
      x[ck + k] = cv[k];
    }

    ak += 3;
  }

  memcpy(&a[0], &x[0], 372U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 371; ck += 3) {
    for (k = 0; k < 3; k++) {
      cv[k] = a[ak + k] / 2.0F;
    }

    for (k = 0; k < 3; k++) {
      x[ck + k] = cv[k];
    }

    ak += 3;
  }

  memcpy(&a[0], &x[0], 372U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 371; ck += 3) {
    for (k = 0; k < 3; k++) {
      cv[k] = a[ak + k];
    }

    for (k = 0; k < 3; k++) {
      x[ck + k] = cv[k];
    }

    ak += 3;
  }
}

/*
 * Arguments    : float n[372]
 *                float a[372]
 * Return Type  : void
 */
static void softmax_apply(float n[372], float a[372])
{
  float nmax[124];
  int ix;
  int iy;
  int i;
  int bk;
  float mtmp;
  int ak;
  boolean_T exitg1;
  float cv[3];
  int k;
  float numer[372];
  float s;
  float b_nmax;

  /*  Competitive Soft Transfer Function */
  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ix += 3;
    bk = ix - 2;
    mtmp = n[ix - 3];
    if (rtIsNaNF(n[ix - 3])) {
      ak = ix - 1;
      exitg1 = false;
      while ((!exitg1) && (ak <= ix)) {
        bk = ak;
        if (!rtIsNaNF(n[ak - 1])) {
          mtmp = n[ak - 1];
          exitg1 = true;
        } else {
          ak++;
        }
      }
    }

    if (bk < ix) {
      while (bk + 1 <= ix) {
        if (n[bk] > mtmp) {
          mtmp = n[bk];
        }

        bk++;
      }
    }

    iy++;
    nmax[iy] = mtmp;
  }

  memcpy(&a[0], &n[0], 372U * sizeof(float));
  ak = 0;
  bk = 0;
  for (ix = 0; ix < 371; ix += 3) {
    for (k = 0; k < 3; k++) {
      cv[k] = a[ak + k] - nmax[bk];
    }

    for (k = 0; k < 3; k++) {
      n[ix + k] = cv[k];
    }

    ak += 3;
    bk++;
  }

  for (ak = 0; ak < 372; ak++) {
    numer[ak] = (real32_T)exp(n[ak]);
  }

  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ak = ix;
    ix++;
    s = numer[ak];
    for (k = 0; k < 2; k++) {
      ix++;
      s += numer[ix - 1];
    }

    iy++;
    nmax[iy] = s;
  }

  for (i = 0; i < 124; i++) {
    b_nmax = nmax[i];
    if (nmax[i] == 0.0F) {
      b_nmax = 1.0F;
    }

    nmax[i] = b_nmax;
  }

  ak = 0;
  bk = 0;
  for (ix = 0; ix < 371; ix += 3) {
    for (k = 0; k < 3; k++) {
      cv[k] = numer[ak + k] / nmax[bk];
    }

    for (k = 0; k < 3; k++) {
      a[ix + k] = cv[k];
    }

    ak += 3;
    bk++;
  }
}

/*
 * Arguments    : const float n[1240]
 *                float a[1240]
 * Return Type  : void
 */
static void tansig_apply(const float n[1240], float a[1240])
{
  int i3;

  /*  Sigmoid Symmetric Transfer Function */
  for (i3 = 0; i3 < 1240; i3++) {
    a[i3] = 2.0F / (1.0F + (real32_T)exp(-2.0F * n[i3])) - 1.0F;
  }
}

/*
 * NEURAL_NET neural network simulation function.
 *
 *  Generated by Neural Network Toolbox function genFunction, 18-Mar-2016 17:47:39.
 *
 *  [y1] = neural_net(x1) takes these arguments:
 *    x = 12xQ matrix, input #1
 *  and returns:
 *    y = 3xQ matrix, output #1
 *  where Q is the number of samples.
 * Arguments    : const float x1[1488]
 *                float b_y1[372]
 * Return Type  : void
 */
void neural_net(const float x1[1488], float b_y1[372])
{
  float xp1[1488];
  static const double dv0[12] = { 16.266226, -41.92286, -11.763175, 0.26042256,
    -48.499973, -10.59572, -11.150261, -44.930916, -17.053158, -19.242487,
    -30.694912, -12.756729 };

  static const double dv1[12] = { 0.0877888208310933, 0.0583581858719483,
    0.0496593431136582, 0.0621090054882946, 0.0398973259870547,
    0.0429406458505015, 0.0418338504206415, 0.0319962551582963,
    0.0406196264042357, 0.0484939453611929, 0.0589816908976134,
    0.0505196259274298 };

  double dv2[372];
  double dv3[1240];
  float fv0[1240];
  int i0;
  int i1;
  float f0;
  int i2;
  static const float fv1[120] = { 0.0230233725F, -0.563492715F, -0.822843552F,
    1.80586565F, 0.276889324F, 0.524122F, -1.33681583F, 0.344835699F,
    -0.695507228F, 1.80522835F, -0.0550596938F, -0.676383853F, -2.41245532F,
    -0.927980423F, 0.394430786F, -0.194554776F, 1.62348616F, 2.38019776F,
    0.215607196F, -0.383696914F, -0.571495473F, 0.0237036627F, -2.25876F,
    -2.05604172F, 1.43950212F, 1.80448389F, 0.769770741F, 0.0642549545F,
    0.992153943F, -1.83704531F, 0.643898F, -1.28870082F, 0.210929364F,
    -0.866296232F, -0.619905412F, 0.923317969F, -0.416617692F, -0.765034556F,
    -0.0413926654F, 1.16685724F, -0.497378767F, 0.593757451F, -0.787604153F,
    1.30307114F, -0.692512095F, -0.170599639F, -2.01519585F, 0.655828416F,
    -1.03089559F, 0.844338953F, 0.632727802F, 1.98791075F, -1.88016605F,
    -0.507284939F, -2.31624675F, 0.222088069F, -0.827230752F, 0.322276831F,
    -2.11210704F, -0.0127154151F, 0.379285634F, 2.03820705F, 1.36583328F,
    -0.737313509F, -1.42465985F, 0.453599334F, 0.921041727F, -1.12556541F,
    0.684141219F, 0.0421251133F, 0.900214434F, -1.20559084F, 3.8022809F,
    0.729370773F, -0.618495584F, -1.3717587F, -1.7405529F, 1.34380484F,
    0.487161607F, 1.32885098F, -0.103990696F, -3.05227852F, 2.38140178F,
    1.12846839F, 2.2922585F, 0.347078741F, -1.04473197F, 0.214843735F,
    0.564522505F, 0.901030898F, -1.29734957F, -0.621741891F, 0.328632116F,
    -1.17510664F, 1.60569668F, 0.429237306F, 2.63376117F, -0.331641793F,
    1.92891824F, -2.39988089F, 0.774254441F, 0.14128463F, -0.685431898F,
    1.63504863F, 0.289251149F, -1.23447287F, -0.866476715F, 0.73839F,
    -1.65670192F, 0.114585452F, -0.490323752F, 2.30650234F, -1.94516778F,
    -0.806429F, -1.75344384F, 0.953305483F, 1.45955014F, -1.09771764F,
    0.137348399F, -1.02980196F };

  float fv2[1240];
  float fv3[372];
  static const float fv4[30] = { 0.381543756F, -0.328486204F, 1.23910904F,
    -2.59554219F, 2.07472944F, 2.61080813F, -3.56231165F, -1.57926285F,
    4.58094072F, -0.210559413F, -3.69704247F, 2.46401215F, 2.2257123F,
    0.609802961F, -3.34585738F, 0.434797019F, 0.881985724F, -2.65839505F,
    -2.09938049F, 3.29723263F, -1.07990241F, 2.87946963F, -0.508662879F,
    -1.14862227F, -1.50144398F, 1.94445717F, 1.11034715F, 1.09698689F,
    -1.93542922F, 1.86008215F };

  float fv5[372];

  /*  ===== NEURAL NETWORK CONSTANTS ===== */
  /*  Input 1 */
  /*  Layer 1 */
  /*  Layer 2 */
  /*  Output 1 */
  /*  ===== SIMULATION ======== */
  /*  Dimensions */
  /*  samples */
  /*  Input 1 */
  mapminmax_apply(x1, dv1, dv0, xp1);

  /*  Layer 1 */
  /*  Layer 2 */
  b_repmat(dv2);
  repmat(dv3);
  for (i0 = 0; i0 < 10; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 12; i2++) {
        f0 += fv1[i0 + 10 * i2] * xp1[i2 + 12 * i1];
      }

      fv0[i0 + 10 * i1] = (float)dv3[i0 + 10 * i1] + f0;
    }
  }

  tansig_apply(fv0, fv2);
  for (i0 = 0; i0 < 3; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 10; i2++) {
        f0 += fv4[i0 + 3 * i2] * fv2[i2 + 10 * i1];
      }

      fv3[i0 + 3 * i1] = (float)dv2[i0 + 3 * i1] + f0;
    }
  }

  /*  Output 1 */
  softmax_apply(fv3, fv5);
  mapminmax_reverse(fv5, b_y1);
}

/*
 * File trailer for neural_net.c
 *
 * [EOF]
 */
