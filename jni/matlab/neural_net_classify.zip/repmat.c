/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: repmat.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 15:56:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "repmat.h"

/* Function Definitions */

/*
 * Arguments    : double b[1984]
 * Return Type  : void
 */
void b_repmat(double b[1984])
{
  int jtilecol;
  int ibtile;
  static const double a[16] = { -0.32492582254552482, -0.17221500327582767,
    -0.29924649408060838, -1.1654019539234926, -0.754017337005746,
    -1.0278628429236523, -0.64244554816840738, 0.8376337842118099,
    0.36208808897411904, 0.16856897037122354, 0.024778701174806902,
    -0.20583476707005222, 1.4837018753015951, -0.65903389653725186,
    -1.1762077954771413, 0.90834432881429661 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol << 4;
    memcpy(&b[ibtile], &a[0], sizeof(double) << 4);
  }
}

/*
 * Arguments    : double b[1240]
 * Return Type  : void
 */
void repmat(double b[1240])
{
  int jtilecol;
  int ibtile;
  static const double a[10] = { 1.772799904215675, -1.0529191787588028,
    -0.67935228974469786, 1.121810068432749, 0.54257722810936182,
    0.060567857446798441, -1.9995442566927872, -0.47573925577352361,
    -1.5973664814403383, 2.0907175226207415 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol * 10;
    memcpy(&b[ibtile], &a[0], 10U * sizeof(double));
  }
}

/*
 * File trailer for repmat.c
 *
 * [EOF]
 */
