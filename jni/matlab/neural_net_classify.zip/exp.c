/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: exp.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 15:56:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "exp.h"

/* Function Definitions */

/*
 * Arguments    : float x[1984]
 * Return Type  : void
 */
void b_exp(float x[1984])
{
  int k;
  for (k = 0; k < 1984; k++) {
    x[k] = (real32_T)exp(x[k]);
  }
}

/*
 * File trailer for exp.c
 *
 * [EOF]
 */
