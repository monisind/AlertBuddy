/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: bsxfun.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 15:56:08
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "bsxfun.h"

/* Function Definitions */

/*
 * Arguments    : const float a[1984]
 *                const float b[124]
 *                float c[1984]
 * Return Type  : void
 */
void b_bsxfun(const float a[1984], const float b[124], float c[1984])
{
  int ak;
  int bk;
  int ck;
  float cv[16];
  int k;
  ak = 0;
  bk = 0;
  for (ck = 0; ck < 1970; ck += 16) {
    for (k = 0; k < 16; k++) {
      cv[k] = a[ak + k] / b[bk];
    }

    memcpy(&c[ck], &cv[0], sizeof(float) << 4);
    ak += 16;
    bk++;
  }
}

/*
 * Arguments    : const float a[1984]
 *                const float b[124]
 *                float c[1984]
 * Return Type  : void
 */
void bsxfun(const float a[1984], const float b[124], float c[1984])
{
  int ak;
  int bk;
  int ck;
  float cv[16];
  int k;
  ak = 0;
  bk = 0;
  for (ck = 0; ck < 1970; ck += 16) {
    for (k = 0; k < 16; k++) {
      cv[k] = a[ak + k] - b[bk];
    }

    memcpy(&c[ck], &cv[0], sizeof(float) << 4);
    ak += 16;
    bk++;
  }
}

/*
 * File trailer for bsxfun.c
 *
 * [EOF]
 */
