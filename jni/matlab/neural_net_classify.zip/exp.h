/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: exp.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 15:56:08
 */

#ifndef __EXP_H__
#define __EXP_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "neural_net_classify_types.h"

/* Function Declarations */
extern void b_exp(float x[1984]);

#endif

/*
 * File trailer for exp.h
 *
 * [EOF]
 */
