/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: repmat.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 17:07:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "repmat.h"

/* Function Definitions */

/*
 * Arguments    : double b[496]
 * Return Type  : void
 */
void b_repmat(double b[496])
{
  int jtilecol;
  int ibtile;
  int k;
  static const double a[4] = { -1.2030485150489938, 1.2669071654155337,
    -1.8541895051745807, 3.1653213652713452 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol << 2;
    for (k = 0; k < 4; k++) {
      b[ibtile + k] = a[k];
    }
  }
}

/*
 * Arguments    : double b[1240]
 * Return Type  : void
 */
void repmat(double b[1240])
{
  int jtilecol;
  int ibtile;
  static const double a[10] = { -2.3366190080665863, -2.0883169768998089,
    2.2799007167744767, -0.16362109574710285, 2.3678192514864786,
    -1.9526779959695533, -1.3746959015922933, -1.2614872832210853,
    -1.1149559464559706, 0.6494560026898073 };

  for (jtilecol = 0; jtilecol < 124; jtilecol++) {
    ibtile = jtilecol * 10;
    memcpy(&b[ibtile], &a[0], 10U * sizeof(double));
  }
}

/*
 * File trailer for repmat.c
 *
 * [EOF]
 */
