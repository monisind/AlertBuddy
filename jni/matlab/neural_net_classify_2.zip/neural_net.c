/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: neural_net.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 18-Mar-2016 17:07:52
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "neural_net_classify.h"
#include "neural_net.h"
#include "repmat.h"

/* Function Declarations */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488]);
static void mapminmax_reverse(const float y[496], float x[496]);
static void softmax_apply(float n[496], float a[496]);
static void tansig_apply(const float n[1240], float a[1240]);

/* Function Definitions */

/*
 * Arguments    : const float x[1488]
 *                const double settings_gain[12]
 *                const double settings_xoffset[12]
 *                float y[1488]
 * Return Type  : void
 */
static void mapminmax_apply(const float x[1488], const double settings_gain[12],
  const double settings_xoffset[12], float y[1488])
{
  int ak;
  int ck;
  float cv[12];
  int k;
  float a[1488];

  /*  ===== MODULE FUNCTIONS ======== */
  /*  Map Minimum and Maximum Input Processing Function */
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = x[ak + k] - (float)settings_xoffset[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] * (float)settings_gain[k];
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }

  memcpy(&a[0], &y[0], 1488U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 1478; ck += 12) {
    for (k = 0; k < 12; k++) {
      cv[k] = a[ak + k] + -1.0F;
    }

    for (k = 0; k < 12; k++) {
      y[ck + k] = cv[k];
    }

    ak += 12;
  }
}

/*
 * Arguments    : const float y[496]
 *                float x[496]
 * Return Type  : void
 */
static void mapminmax_reverse(const float y[496], float x[496])
{
  int ak;
  int ck;
  float cv[4];
  int k;
  float a[496];

  /*  Map Minimum and Maximum Output Reverse-Processing Function */
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = y[ak + k] - -1.0F;
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }

  memcpy(&a[0], &x[0], 496U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k] / 2.0F;
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }

  memcpy(&a[0], &x[0], 496U * sizeof(float));
  ak = 0;
  for (ck = 0; ck < 494; ck += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k];
    }

    for (k = 0; k < 4; k++) {
      x[ck + k] = cv[k];
    }

    ak += 4;
  }
}

/*
 * Arguments    : float n[496]
 *                float a[496]
 * Return Type  : void
 */
static void softmax_apply(float n[496], float a[496])
{
  float nmax[124];
  int ix;
  int iy;
  int i;
  int bk;
  float mtmp;
  int ak;
  boolean_T exitg1;
  float cv[4];
  int k;
  float numer[496];
  float s;
  float b_nmax;

  /*  Competitive Soft Transfer Function */
  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ix += 4;
    bk = ix - 3;
    mtmp = n[ix - 4];
    if (rtIsNaNF(n[ix - 4])) {
      ak = ix - 2;
      exitg1 = false;
      while ((!exitg1) && (ak <= ix)) {
        bk = ak;
        if (!rtIsNaNF(n[ak - 1])) {
          mtmp = n[ak - 1];
          exitg1 = true;
        } else {
          ak++;
        }
      }
    }

    if (bk < ix) {
      while (bk + 1 <= ix) {
        if (n[bk] > mtmp) {
          mtmp = n[bk];
        }

        bk++;
      }
    }

    iy++;
    nmax[iy] = mtmp;
  }

  memcpy(&a[0], &n[0], 496U * sizeof(float));
  ak = 0;
  bk = 0;
  for (ix = 0; ix < 494; ix += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = a[ak + k] - nmax[bk];
    }

    for (k = 0; k < 4; k++) {
      n[ix + k] = cv[k];
    }

    ak += 4;
    bk++;
  }

  for (ak = 0; ak < 496; ak++) {
    numer[ak] = (real32_T)exp(n[ak]);
  }

  ix = 0;
  iy = -1;
  for (i = 0; i < 124; i++) {
    ak = ix;
    ix++;
    s = numer[ak];
    for (k = 0; k < 3; k++) {
      ix++;
      s += numer[ix - 1];
    }

    iy++;
    nmax[iy] = s;
  }

  for (i = 0; i < 124; i++) {
    b_nmax = nmax[i];
    if (nmax[i] == 0.0F) {
      b_nmax = 1.0F;
    }

    nmax[i] = b_nmax;
  }

  ak = 0;
  bk = 0;
  for (ix = 0; ix < 494; ix += 4) {
    for (k = 0; k < 4; k++) {
      cv[k] = numer[ak + k] / nmax[bk];
    }

    for (k = 0; k < 4; k++) {
      a[ix + k] = cv[k];
    }

    ak += 4;
    bk++;
  }
}

/*
 * Arguments    : const float n[1240]
 *                float a[1240]
 * Return Type  : void
 */
static void tansig_apply(const float n[1240], float a[1240])
{
  int i3;

  /*  Sigmoid Symmetric Transfer Function */
  for (i3 = 0; i3 < 1240; i3++) {
    a[i3] = 2.0F / (1.0F + (real32_T)exp(-2.0F * n[i3])) - 1.0F;
  }
}

/*
 * NEURAL_NET neural network simulation function.
 *
 *  Generated by Neural Network Toolbox function genFunction, 18-Mar-2016 17:06:39.
 *
 *  [y1] = neural_net(x1) takes these arguments:
 *    x = 12xQ matrix, input #1
 *  and returns:
 *    y = 4xQ matrix, output #1
 *  where Q is the number of samples.
 * Arguments    : const float x1[1488]
 *                float b_y1[496]
 * Return Type  : void
 */
void neural_net(const float x1[1488], float b_y1[496])
{
  float xp1[1488];
  static const double dv0[12] = { 14.217573, -44.983524, -18.36889, -4.2858396,
    -41.104713, -11.332692, -11.150261, -44.45419, -13.044455, -18.191732,
    -33.791695, -13.485515 };

  static const double dv1[12] = { 0.0734540268691158, 0.0509866859333796,
    0.0430732106962929, 0.0548098979528492, 0.0486118147824901,
    0.0386407595057669, 0.0404083579758653, 0.0360912068105551,
    0.0381381336886892, 0.0386561610817695, 0.0448118940087573,
    0.0394800049073646 };

  double dv2[496];
  double dv3[1240];
  float fv0[1240];
  int i0;
  int i1;
  float f0;
  int i2;
  static const float fv1[120] = { -6.19899559F, 0.110081635F, -1.2229563F,
    -0.223624408F, 0.801216662F, -3.49775434F, -4.40311575F, 1.54156423F,
    -2.71197748F, -0.582821846F, 1.51820648F, -0.51961571F, 1.03725851F,
    3.15342593F, -1.63779509F, 1.1057235F, 1.56504619F, 1.39219344F, 1.10895574F,
    4.0211072F, 2.07594109F, 0.0806121901F, -1.09027302F, 3.02610278F,
    -1.79971683F, -1.23121595F, -0.81005168F, -1.41912353F, 2.36895323F,
    2.01871F, 1.27754927F, -0.937877595F, -0.269860297F, 0.181136951F,
    -3.20733118F, -2.24666429F, -1.88040662F, -2.47129583F, 1.79617774F,
    1.78721941F, -1.9908613F, 2.85335302F, 1.72875023F, 0.0919054821F,
    0.3676624F, 1.57292926F, -1.04711342F, -1.28291667F, -1.30092239F,
    -0.516858101F, -1.10159528F, 3.02472258F, -0.968754888F, 1.55172455F,
    3.17741847F, 0.238355547F, -1.51369822F, -0.545405209F, -1.56812513F,
    -1.42766738F, 1.01960886F, -0.788021147F, -0.571790278F, 0.675691843F,
    4.17823553F, 0.818369389F, 1.31211495F, 0.927076459F, 2.53272533F,
    -0.142174542F, 1.62001598F, -3.7309F, 1.84243453F, -2.84448886F,
    -1.25503445F, -2.01927328F, 1.41196477F, 4.16254139F, -0.550115645F,
    -0.711503267F, -1.06621909F, -2.03674722F, -0.312699556F, -2.14774179F,
    -1.83415616F, -1.20920599F, -0.572369516F, -0.284677982F, -0.769599617F,
    -1.23140299F, -1.07409859F, 1.3107444F, -1.33036959F, -0.495982438F,
    -1.02009976F, 2.51470852F, 0.991679847F, -2.59081769F, 2.47639298F,
    -0.32243973F, 1.69406986F, 2.7807529F, 0.629442513F, 1.53144F, -1.62150812F,
    -1.773F, 1.5917505F, 1.43644142F, -4.29470873F, -0.253627717F, 1.11278498F,
    2.35579133F, -0.843655586F, 2.42904949F, 2.18830729F, 0.493758589F,
    0.0374976322F, -0.784996271F, 3.13675618F, -1.00254834F };

  float fv2[1240];
  float fv3[496];
  static const float fv4[40] = { -3.43032026F, 0.901465237F, -1.83151114F,
    6.36191463F, -2.52239084F, 0.0682738274F, -3.00524545F, 5.57004452F,
    0.584331751F, 0.243433878F, -3.48245454F, 1.92039692F, 5.36264181F,
    -2.3061564F, -2.63763475F, -1.5451405F, -4.45818615F, -0.49747172F,
    1.63431215F, 2.78023911F, 0.91919297F, 3.68373179F, 1.9685874F, -5.41593647F,
    -3.37690902F, 1.46130252F, 1.04138255F, 2.7414124F, 4.60496902F,
    -3.76767397F, -2.06155276F, 2.87121105F, -1.75545812F, 7.50368214F,
    -3.36776567F, -2.48305273F, 4.78960514F, -2.13422132F, 0.95077F,
    -2.89868808F };

  float fv5[496];

  /*  ===== NEURAL NETWORK CONSTANTS ===== */
  /*  Input 1 */
  /*  Layer 1 */
  /*  Layer 2 */
  /*  Output 1 */
  /*  ===== SIMULATION ======== */
  /*  Dimensions */
  /*  samples */
  /*  Input 1 */
  mapminmax_apply(x1, dv1, dv0, xp1);

  /*  Layer 1 */
  /*  Layer 2 */
  b_repmat(dv2);
  repmat(dv3);
  for (i0 = 0; i0 < 10; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 12; i2++) {
        f0 += fv1[i0 + 10 * i2] * xp1[i2 + 12 * i1];
      }

      fv0[i0 + 10 * i1] = (float)dv3[i0 + 10 * i1] + f0;
    }
  }

  tansig_apply(fv0, fv2);
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 124; i1++) {
      f0 = 0.0F;
      for (i2 = 0; i2 < 10; i2++) {
        f0 += fv4[i0 + (i2 << 2)] * fv2[i2 + 10 * i1];
      }

      fv3[i0 + (i1 << 2)] = (float)dv2[i0 + (i1 << 2)] + f0;
    }
  }

  /*  Output 1 */
  softmax_apply(fv3, fv5);
  mapminmax_reverse(fv5, b_y1);
}

/*
 * File trailer for neural_net.c
 *
 * [EOF]
 */
